import Agents.AlphaBetaAgent as AlphaBetaAgent
def agent(obs, config):
    return AlphaBetaAgent.agent(obs, config)